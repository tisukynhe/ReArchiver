# ReArchiver — Android project

Minimalist black/purple file manager starter project.

## Included in this MVP
- Browse shared storage using Android's Storage Access Framework (SAF).
- Create folders and text files, rename, delete, and edit text files.
- Dark black/purple Compose interface.
- Optional privileged shell backend for devices where `su` or Shizuku is available.
- Offline-first; no network permission is requested.

## Important Android limitations
Modern Android restricts direct access to `/Android/data` and `/Android/obb`. SAF access varies by Android version and device. Root (`su`) requires a rooted device and user approval. Shizuku requires the Shizuku app/service to be installed and started, and permission granted to ReArchiver. This starter exposes the shell bridge but does not yet include a complete Shizuku onboarding/provider flow or broad device testing. Use SAF where possible and privileged access only on devices you own/manage.

## Build an APK
1. Install Android Studio (current stable) and Android SDK.
2. Open this folder in Android Studio.
3. Let Gradle sync and install any requested SDK components.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.

This environment generated the source project, not a compiled APK. A local Android SDK/Gradle build is needed to produce the installable APK.

## Requirements
- Android Studio / Android SDK
- JDK 17


## Build in the cloud from a phone (GitHub Actions)

This project includes `.github/workflows/android-build.yml`. On GitHub:
1. Create a new repository and upload the contents of this project (extract the ZIP first).
2. Open the repository's **Actions** tab and enable workflows if prompted.
3. Select **Build ReArchiver APK** and press **Run workflow** (or push to `main`).
4. Open the completed run, find **Artifacts**, and download `ReArchiver-debug-apk`.
5. Extract that artifact ZIP to get `app-debug.apk`.

The cloud workflow has not been run from this environment, so it does not guarantee a successful build. If it fails, open the run and check the build log; the Kotlin/Gradle project may need fixes before an APK can be produced.
