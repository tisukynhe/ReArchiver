package com.rearchiver

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.documentfile.provider.DocumentFile
import rikka.shizuku.Shizuku
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.DecimalFormat

private val Black = Color(0xFF0B0B0F)
private val PanelColor = Color(0xFF15141C)
private val Purple = Color(0xFF9B5CFF)
private val Muted = Color(0xFFAAA5B8)
private val White = Color(0xFFF5F2FA)

class MainActivity : ComponentActivity() {
    private var shizukuStatus by mutableStateOf("Shizuku não verificado")
    private val shizukuPermissionListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == ShizukuBridge.REQUEST_CODE) {
            shizukuStatus = if (grantResult == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                "Permissão Shizuku concedida"
            } else {
                "Permissão Shizuku negada"
            }
        }
    }
    private var onTreePicked: ((Uri) -> Unit)? = null
    private val pickTree = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
            onTreePicked?.invoke(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppContextHolder.context = applicationContext
        Shizuku.addRequestPermissionResultListener(shizukuPermissionListener)
        setContent {
            ReArchiverTheme {
                ReArchiverApp(
                    onPickFolder = { callback ->
                        onTreePicked = callback
                        pickTree.launch(null)
                    },
                    shizukuStatus = shizukuStatus,
                    onRequestShizuku = {
                        runCatching { ShizukuBridge.requestPermission() }
                            .onSuccess { shizukuStatus = if (ShizukuBridge.hasPermission()) "Permissão Shizuku concedida" else "Pedido de permissão enviado" }
                            .onFailure { shizukuStatus = it.message ?: "Shizuku indisponível" }
                    },
                    onTestShizuku = {
                        Thread {
                            val result = runCatching { ShizukuBridge.testShell() }
                            runOnUiThread {
                                shizukuStatus = result.fold(
                                    { "Shizuku OK: " + it.take(180).replace("\\n", " · ") },
                                    { "Falha Shizuku: " + (it.message ?: "erro desconhecido") }
                                )
                            }
                        }.start()
                    }
                )
            }
        }
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(shizukuPermissionListener)
        super.onDestroy()
    }
}

@Composable
private fun ReArchiverTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Purple,
            onPrimary = Color.White,
            background = Black,
            surface = PanelColor,
            onSurface = White,
            secondary = Purple
        ),
        content = content
    )
}

private data class Entry(val file: DocumentFile, val isDirectory: Boolean)

@Composable
private fun ReArchiverApp(
    onPickFolder: ((Uri) -> Unit) -> Unit,
    shizukuStatus: String,
    onRequestShizuku: () -> Unit,
    onTestShizuku: () -> Unit
) {
    var rootUri by remember { mutableStateOf<Uri?>(null) }
    var current by remember { mutableStateOf<DocumentFile?>(null) }
    var entries by remember { mutableStateOf<List<Entry>>(emptyList()) }
    var selected by remember { mutableStateOf<DocumentFile?>(null) }
    var editorText by remember { mutableStateOf("") }
    var editorOpen by remember { mutableStateOf(false) }
    var dialog by remember { mutableStateOf("") }
    var nameInput by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Escolha uma pasta para começar") }
    var accessMode by remember { mutableStateOf("Padrão (SAF)") }
    val scope = rememberCoroutineScope()

    fun refresh(folder: DocumentFile?) {
        current = folder
        entries = folder?.listFiles()?.map { Entry(it, it.isDirectory) }
            ?.sortedWith(compareByDescending<Entry> { it.isDirectory }.thenBy { it.file.name?.lowercase() ?: "" })
            ?: emptyList()
    }

    fun openEditor(file: DocumentFile) {
        selected = file
        scope.launch {
            editorText = withContext(Dispatchers.IO) {
                runCatching { contentResolverSafeRead(file) }.getOrDefault("")
            }
            editorOpen = true
        }
    }

    Surface(modifier = Modifier.fillMaxSize(), color = Black) {
        Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
            Spacer(Modifier.height(18.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(44.dp).background(Purple.copy(alpha = .18f), RoundedCornerShape(14.dp)),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Default.FolderZip, null, tint = Purple, modifier = Modifier.size(26.dp)) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("ReArchiver", color = White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                    Text("Gerenciador de arquivos", color = Muted, fontSize = 12.sp)
                }
                IconButton(onClick = { onPickFolder { uri ->
                    rootUri = uri
                    refresh(DocumentFile.fromTreeUri(AppContextHolder.context, uri))
                    status = "Pasta selecionada"
                } }) {
                    Icon(Icons.Default.FolderOpen, "Escolher pasta", tint = Purple)
                }
            }
            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ModeChip("Padrão", accessMode == "Padrão (SAF)") { accessMode = "Padrão (SAF)" }
                ModeChip("Root (su)", accessMode == "Root (su)") { accessMode = "Root (su)"; status = "Root requer dispositivo com root e autorização do su." }
                ModeChip("Shizuku", accessMode == "Shizuku") { accessMode = "Shizuku"; status = "Shizuku ainda precisa de integração/permissão configurada." }
            }
            if (accessMode == "Shizuku") {
                Spacer(Modifier.height(8.dp))
                Column(Modifier.fillMaxWidth().background(PanelColor, RoundedCornerShape(14.dp)).padding(12.dp)) {
                    Text("Acesso avançado", color = White, fontWeight = FontWeight.SemiBold)
                    Text(shizukuStatus, color = Muted, fontSize = 11.sp)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ActionButton("Conectar", Icons.Default.Security, onRequestShizuku)
                        ActionButton("Testar acesso", Icons.Default.Bolt, onTestShizuku)
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            Column(Modifier.fillMaxWidth().background(PanelColor, RoundedCornerShape(16.dp)).padding(14.dp)) {
                Text(current?.name ?: "Nenhuma pasta aberta", color = White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(status, color = Muted, fontSize = 12.sp)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ActionButton("Pasta", Icons.Default.CreateNewFolder) { dialog = "folder"; nameInput = "" }
                    ActionButton("Arquivo", Icons.Default.NoteAdd) { dialog = "file"; nameInput = "" }
                    ActionButton("Atualizar", Icons.Default.Refresh) { refresh(current) }
                }
            }
            Spacer(Modifier.height(12.dp))
            if (current != null) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Text("${entries.size} itens", color = Muted, fontSize = 12.sp)
                    Spacer(Modifier.weight(1f))
                    Text("Toque para abrir • ⋮ para ações", color = Muted, fontSize = 11.sp)
                }
                Spacer(Modifier.height(8.dp))
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.weight(1f)) {
                if (current != null && current != DocumentFile.fromTreeUri(AppContextHolder.context, rootUri!!)) {
                    item {
                        FileRow("..", "Voltar para a pasta anterior", true, Icons.Default.ArrowUpward) {
                            val parent = current?.parentFile
                            if (parent != null) refresh(parent) else rootUri?.let { refresh(DocumentFile.fromTreeUri(AppContextHolder.context, it)) }
                        }
                    }
                }
                items(entries, key = { it.file.uri.toString() }) { entry ->
                    FileRow(
                        entry.file.name ?: "Sem nome",
                        if (entry.isDirectory) "Pasta" else readableSize(entry.file.length()),
                        entry.isDirectory,
                        if (entry.isDirectory) Icons.Default.Folder else Icons.Default.Description,
                        onClick = {
                            if (entry.isDirectory) refresh(entry.file) else openEditor(entry.file)
                        },
                        onMore = { selected = entry.file; dialog = "actions" }
                    )
                }
                if (current == null) {
                    item {
                        Column(Modifier.fillMaxWidth().padding(top = 44.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.FolderOpen, null, tint = Purple, modifier = Modifier.size(54.dp))
                            Spacer(Modifier.height(12.dp))
                            Text("Abra uma pasta para começar", color = White, fontWeight = FontWeight.Medium)
                            Text("Use o ícone de pasta no topo e conceda acesso.", color = Muted, fontSize = 12.sp)
                        }
                    }
                }
            }
            Text("Offline • ReArchiver 0.1.0", color = Muted, fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(vertical = 12.dp))
        }
    }

    if (dialog == "folder" || dialog == "file" || dialog == "rename") {
        val title = when (dialog) { "folder" -> "Criar pasta"; "file" -> "Criar arquivo"; else -> "Renomear" }
        AlertDialog(
            onDismissRequest = { dialog = "" },
            title = { Text(title) },
            text = {
                OutlinedTextField(value = nameInput, onValueChange = { nameInput = it }, label = { Text("Nome") }, singleLine = true)
            },
            confirmButton = {
                TextButton(onClick = {
                    val parent = current
                    val n = nameInput.trim()
                    if (parent != null && n.isNotEmpty()) {
                        when (dialog) {
                            "folder" -> parent.createDirectory(n)
                            "file" -> parent.createFile("text/plain", n)
                            "rename" -> selected?.renameTo(n)
                        }
                        refresh(current)
                    } else status = "Abra uma pasta antes de criar itens."
                    dialog = ""
                }) { Text("Salvar") }
            },
            dismissButton = { TextButton(onClick = { dialog = "" }) { Text("Cancelar") } }
        )
    }

    if (dialog == "actions" && selected != null) {
        AlertDialog(
            onDismissRequest = { dialog = "" },
            title = { Text(selected?.name ?: "Ações") },
            text = { Text("Escolha uma ação para este item.") },
            confirmButton = {
                Column {
                    TextButton(onClick = { nameInput = selected?.name ?: ""; dialog = "rename" }) { Text("Renomear") }
                    TextButton(onClick = {
                        val f = selected
                        if (f?.isFile == true) openEditor(f) else status = "Editor disponível para arquivos de texto."
                        dialog = ""
                    }) { Text("Editar arquivo") }
                    TextButton(onClick = {
                        val source = selected
                        val parent = current
                        if (source != null && parent != null) {
                            val zipName = (source.name ?: "arquivo").substringBeforeLast('.', source.name ?: "arquivo") + ".zip"
                            val destination = parent.createFile("application/zip", zipName)
                            if (destination != null) {
                                scope.launch(Dispatchers.IO) {
                                    val result = runCatching { ArchiveUtils.zip(contentResolverFromContext(), source, destination) }
                                    withContext(Dispatchers.Main) {
                                        status = result.fold({ "ZIP criado: $zipName" }, { "Erro ao compactar: ${it.message}" })
                                        refresh(current)
                                    }
                                }
                            } else status = "Não foi possível criar o ZIP."
                        }
                        dialog = ""
                    }) { Text("Compactar em ZIP") }
                    if ((selected?.name ?: "").endsWith(".zip", ignoreCase = true)) {
                        TextButton(onClick = {
                            val source = selected
                            val destination = current
                            if (source != null && destination != null) {
                                scope.launch(Dispatchers.IO) {
                                    val result = runCatching { ArchiveUtils.extract(contentResolverFromContext(), source, destination) }
                                    withContext(Dispatchers.Main) {
                                        status = result.fold({ "Extração concluída" }, { "Erro ao extrair: ${it.message}" })
                                        refresh(current)
                                    }
                                }
                            }
                            dialog = ""
                        }) { Text("Extrair aqui") }
                    }
                    TextButton(onClick = {
                        selected?.delete()
                        refresh(current)
                        dialog = ""
                    }) { Text("Excluir", color = Color(0xFFFF6B7A)) }
                }
            },
            dismissButton = { TextButton(onClick = { dialog = "" }) { Text("Fechar") } }
        )
    }

    if (editorOpen && selected != null) {
        AlertDialog(
            onDismissRequest = { editorOpen = false },
            title = { Text("Editar: ${selected?.name}") },
            text = {
                Column {
                    Text("Editor simples de texto", color = Muted, fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                    BasicTextField(
                        value = editorText,
                        onValueChange = { editorText = it },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 180.dp, max = 400.dp)
                            .background(Black, RoundedCornerShape(10.dp)).padding(12.dp),
                        textStyle = androidx.compose.ui.text.TextStyle(color = White, fontSize = 13.sp)
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val f = selected
                    if (f != null) {
                        runCatching {
                            contentResolverOpenOutput(f.uri).use { stream -> stream.write(editorText.toByteArray(Charsets.UTF_8)) }
                            status = "Arquivo salvo"
                        }.onFailure { status = "Não foi possível salvar este arquivo." }
                    }
                    editorOpen = false
                    refresh(current)
                }) { Text("Salvar") }
            },
            dismissButton = { TextButton(onClick = { editorOpen = false }) { Text("Cancelar") } }
        )
    }
}

@Composable
private fun ModeChip(label: String, active: Boolean, onClick: () -> Unit) {
    Surface(
        color = if (active) Purple.copy(alpha = .22f) else PanelColor,
        shape = RoundedCornerShape(50),
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Text(label, color = if (active) Purple else Muted, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 13.dp, vertical = 9.dp))
    }
}

@Composable
private fun ActionButton(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Surface(color = Black, shape = RoundedCornerShape(10.dp), modifier = Modifier.clickable(onClick = onClick)) {
        Row(Modifier.padding(horizontal = 10.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Purple, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(5.dp))
            Text(label, color = White, fontSize = 11.sp)
        }
    }
}

@Composable
private fun FileRow(
    name: String, detail: String, isFolder: Boolean,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    onMore: (() -> Unit)? = null
) {
    Row(
        Modifier.fillMaxWidth().background(PanelColor, RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = if (isFolder) Purple else Muted, modifier = Modifier.size(23.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(name, color = White, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(detail, color = Muted, fontSize = 11.sp)
        }
        if (onMore != null) {
            IconButton(onClick = onMore, modifier = Modifier.size(32.dp)) {
                Icon(Icons.Default.MoreVert, "Ações", tint = Muted)
            }
        }
    }
}

private fun readableSize(size: Long): String {
    if (size < 1024) return "$size B"
    val kb = size / 1024.0
    if (kb < 1024) return "${DecimalFormat("#,##0.#").format(kb)} KB"
    return "${DecimalFormat("#,##0.#").format(kb / 1024)} MB"
}

// Kept separate so UI code can be evolved to support more providers.
private fun contentResolverFromContext() = AppContextHolder.context.contentResolver

private fun contentResolverSafeRead(file: DocumentFile): String {
    val uri = file.uri
    val resolver = AppContextHolder.context.contentResolver
    return resolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
}
private fun contentResolverOpenOutput(uri: Uri) =
    AppContextHolder.context.contentResolver.openOutputStream(uri, "wt")
        ?: error("Não foi possível abrir o arquivo para escrita")

private object AppContextHolder {
    lateinit var context: android.content.Context
}

