package com.rearchiver

import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader

object ShizukuBridge {
    const val REQUEST_CODE = 7401

    fun isServiceRunning(): Boolean = Shizuku.pingBinder()

    fun hasPermission(): Boolean =
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED

    fun requestPermission() {
        if (!Shizuku.pingBinder()) error("Abra o Shizuku e inicie o serviço primeiro.")
        if (!hasPermission()) Shizuku.requestPermission(REQUEST_CODE)
    }

    @Suppress("DEPRECATION")
    fun testShell(): String {
        check(hasPermission()) { "Permissão Shizuku não concedida." }
        val process = Shizuku.newProcess(arrayOf("sh", "-c", "id; ls -ld /storage/emulated/0/Android/data /storage/emulated/0/Android/obb 2>&1"), null, null)
        val output = BufferedReader(InputStreamReader(process.inputStream)).use { it.readText() }
        val errors = BufferedReader(InputStreamReader(process.errorStream)).use { it.readText() }
        val code = process.waitFor()
        if (code != 0) error(errors.ifBlank { "Comando terminou com código $code" })
        return (output + errors).trim()
    }
}
