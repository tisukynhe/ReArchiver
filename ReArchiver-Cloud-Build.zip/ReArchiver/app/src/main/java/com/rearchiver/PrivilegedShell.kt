package com.rearchiver

import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * Privileged shell helper. Only use for explicit user-requested file operations.
 * Root mode requires a rooted device and an interactive su authorization grant.
 * This is not yet wired into the UI; SAF remains the default and safest backend.
 */
object PrivilegedShell {
    fun isSuAvailable(): Boolean = runCatching {
        val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))
        val out = BufferedReader(InputStreamReader(p.inputStream)).readText()
        p.waitFor() == 0 && out.contains("uid=0")
    }.getOrDefault(false)

    fun run(command: String): Result<String> = runCatching {
        // Callers must build commands with robust shell escaping and validate paths.
        val p = Runtime.getRuntime().exec(arrayOf("su", "-c", command))
        val output = BufferedReader(InputStreamReader(p.inputStream)).readText()
        val error = BufferedReader(InputStreamReader(p.errorStream)).readText()
        val code = p.waitFor()
        if (code != 0) error("su exited $code: $error")
        output
    }
}
