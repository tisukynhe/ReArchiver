package com.rearchiver

import android.content.ContentResolver
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object ArchiveUtils {
    fun zip(resolver: ContentResolver, source: DocumentFile, destination: DocumentFile) {
        val output = resolver.openOutputStream(destination.uri, "wt")
            ?: error("Não foi possível criar o ZIP")
        ZipOutputStream(output.buffered()).use { zip ->
            addToZip(resolver, source, source.name ?: "item", zip)
        }
    }

    private fun addToZip(resolver: ContentResolver, file: DocumentFile, path: String, zip: ZipOutputStream) {
        if (file.isDirectory) {
            val dirPath = if (path.endsWith("/")) path else "$path/"
            zip.putNextEntry(ZipEntry(dirPath))
            zip.closeEntry()
            file.listFiles().forEach { child ->
                addToZip(resolver, child, dirPath + (child.name ?: "item"), zip)
            }
        } else {
            zip.putNextEntry(ZipEntry(path))
            resolver.openInputStream(file.uri)?.use { input -> input.copyTo(zip) }
                ?: error("Não foi possível ler ${file.name}")
            zip.closeEntry()
        }
    }

    fun extract(resolver: ContentResolver, zipFile: DocumentFile, destination: DocumentFile) {
        val input = resolver.openInputStream(zipFile.uri) ?: error("Não foi possível abrir o ZIP")
        ZipInputStream(input.buffered()).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                val parts = entry.name.replace('\\', '/').split('/')
                require(!entry.name.startsWith("/") && parts.none { it == ".." }) {
                    "O ZIP contém um caminho inseguro"
                }
                var parent = destination
                val dirs = parts.dropLast(1).filter { it.isNotBlank() }
                for (dir in dirs) {
                    parent = parent.findFile(dir) ?: parent.createDirectory(dir)
                    require(parent.isDirectory) { "Conflito com arquivo existente" }
                }
                val leaf = parts.lastOrNull().orEmpty()
                if (entry.isDirectory || leaf.isBlank()) {
                    if (leaf.isNotBlank()) parent.findFile(leaf) ?: parent.createDirectory(leaf)
                } else {
                    val outFile = parent.findFile(leaf) ?: parent.createFile("application/octet-stream", leaf)
                    ?: error("Não foi possível criar $leaf")
                    val output = resolver.openOutputStream(outFile.uri, "wt")
                        ?: error("Não foi possível escrever $leaf")
                    output.use { zip.copyTo(it) }
                }
                zip.closeEntry()
            }
        }
    }
}
